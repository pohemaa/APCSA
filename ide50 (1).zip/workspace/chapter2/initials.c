#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int main(void)
{
    // printf("What is your name?");
    string name = GetString();
    printf("%c", toupper(name[0]));
  
    for( int i = 1, len = strlen(name); i < len; i++)
    {
       
        if (isspace(name[i - 1]) )
        {
            printf("%c", toupper(name[i])); 
            
        }
      
    }
    printf("\n");
    
}

/*Get user input
store it in  a string
create an initial string
output the first initial
For loop to look at each character
when there is a space
get next letter.
capitalize it
printf("%c", name[i]);
if(isspace(name[i]) && i+1<len)
{
    printf("%c",)
}
*/