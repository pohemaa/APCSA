#include <cs50.h> 
#include <stdio.h> 
#include <math.h> 
#include <stdlib.h> 
 
int calculateISBN(long long ISBN); 
void answer(int sum); 
 
int main(void) 
 
{ 
    printf("ISBN:"); 
    long long ISBN=get_long_long(); 
    int total=calculateISBN(ISBN); 
    answer(total); 
} 
 
int calculateISBN(long long ISBN) 
{ 
     int last=0; 
     int sum=0; 
     for (int x=10; x > 0; x--) 
    { 
         
        last = ISBN % 10; 
        sum = sum + (x * last); 
        ISBN = ISBN / 10; 
    } 
    return sum; 
} 
 
void answer(int sum) 
{ 
    if (sum == 0) 
    { 
        printf("YES\n"); 
    } 
    else 
    { 
        printf("NO\n"); 
    } 
}