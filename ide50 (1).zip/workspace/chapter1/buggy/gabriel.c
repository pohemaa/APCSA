#include <cs50.h> 
#include <stdio.h> 
 
 
  
 
 
long long input(); 
int calculate(long long x); 
 
 
 
 
int main(void) 
{ 
    long long x = input(); 
    int total = calculate(x); 
   
} 
 
 
long long input() 
{ 
    printf("ISBN: "); 
    long long x = get_long_long(); 
    return x; 
} 
     
int calculate(long long x)     
{ 
    int mult = 10; 
    int total = 0; 
    do 
    { 
        int tenth = x % 10; 
        total = total + (tenth * mult); 
        x = x / 10; 
        mult--; 
    } 
    while (mult != 0); 
    return total; 
} 
     
void check(int total) 
{ 
    if (total % 11 == 0) 
    { 
        printf("YES\n"); 
    } 
     
    else 
    { 
        printf("NO\n"); 
    } 
} 