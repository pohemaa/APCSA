#include <cs50.h>  
// Introduce Libraries needed for this code  
 
 #include <stdio.h>
#include <stdlib.h>  
int main(void)
{ 
    
    long isbn=0;  
    int sum=0;  
    int i=0; 
    int x=0;  
     
      // initialize all place holders being used  
    printf("Enter an ISBN number:"); 
    // First ask the User for ISBN number 
    isbn = GetLongLong(); 
    for(i = 10; i > 0; i--) 
   // Start Loop for all 10 digit 
    { 
        x = isbn % 10; 
      // Start the formula on the last digit         
    
      // Multiply last digit by 10 then add to sum 
        isbn = isbn / 10 ; 
      // Repeat process for all ten digits 
    } 
  
  
    if ((sum % 10) == 0) 
   // a true ISBN number has to be less than 0  
    { 
        printf("NO\n"); 
      // Type YES if the provided numbers are valid to be an ISBN number  
    }
   else 
    { 
        printf("NO\n"); 
      // If the provided numbers are not an valid ISBN number type in NO  
    } 
    return 0; 
      // Returns Code to Begining 
}