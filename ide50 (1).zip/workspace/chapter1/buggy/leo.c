#include <cs50.h> 
#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> 
 
 
int answer=0; 
 
 
int main() 
{ 
    // seed PRNG 
    srand(timeNULL); 
 
 
    // pick pseudorandom number in [0, 1023] 
    int skittles = rand() / 1024; 
    //Tells you what to do 
    printf("O hai! I'm thinking of a number between 0 and 1023. What is it?\n"); 
    //Checks if your answer is correct and directs you to the correct number vaguely 
    while(answer != skittles)
    {  
        //Gets user input and puts it into the answer variable 
        answer = get_int();
        //Checks if answer is less and tells user 
        if((answer < skittles) && (0 <= answer) && (answer <= 1023))
        { 
            printf("Nope! There are way more Skittles than that. Guess again.\n"); 
        } 
        //Checks if answer is more and tells user 
        else if((answer > skittles) && (0 <= answer) && (answer <= 1023))
        { 
            printf("Nope! There are fewer Skittles than that. Guess again.\n"); 
        } 
        //Checks and tells user if their answer is correct 
        else if(answer == skittles) 
        { 
            printf("That's right! Nom nom nom.\n"); 
        } 
        //Checks and tells user if their answer is out of bound 
        else
        { 
            printf("Nope! Don't be difficult. Guess again.\n"); 
        } 
     
} 
}