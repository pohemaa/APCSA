#include cs50.h
#include stdio.h
#include stdlib.h
#include math.h

long isbn()
int calculateISBN (isbn)
int checkISBN(sum)

int main (void);
{
    printf("ISBN:");
    long isbn= get_long_long();
    int sum = calculateISBN(isbn);
    checkISBN(sum); 
}    

int calculateISBN(long isbn);
{
    int y = 0;
    for(int i=10; i > 0; i--)
    {
        int mod = isbn % 10;
        isbn = isbn / 10;
        
        y = y + (mod * i);
        
    } 
    
}
    
int checkISBN(int sum);
{
    int y = sum % 11;

    if (y != 0)
    {
    printf("NO\n");
    }
    else
    {
    printf("YES\n");
    }
    return sum;
}


