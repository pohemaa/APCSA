
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
    srand( time(NULL) );
    int skittles = rand() % 1024;
    printf("I'm thinking of a number between 0 and 1023:.\n");
    
     while (skittles<1024)
    {
        int youtube=get_int();
        if (youtube<skittles)
       {
        printf("Nope!! You guessed the wrong number. Try again, maybe with a higher number\n");
       }
        else if (youtube>skittles) //if the number the user inputs is larger than the number the computer chose it prints what is below.
        {
            printf("Try again with a number lesser than that\n");
        }
        
        else //if the user's input is the same as the computer's number, the sentence below is printed and the game is ended.
        {
            printf("Yaayyyyyy!!!!! You got that right.\n");
            
        }
    }
    
   
    
}

//Good job! Here are the issues with the code:
/*  1. The program allows numbers greater than 1023 and less than 0.
    2. The program never ends.
*/
//Grade: 10/12