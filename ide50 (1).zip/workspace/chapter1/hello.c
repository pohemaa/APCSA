#include <stdio.h>
int main(void)
{
    printf("hello, world\n");
}

//Not a big deal, but you should start using comments to describe your code :)
//Grade: 8/8