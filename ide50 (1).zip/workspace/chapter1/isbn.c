#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
    printf("ISBN:");
    long isbn= get_long_long();
    int mod=0;
    int y=0;
    for(int i=10; i > 0; i--)
    {
        mod = isbn % 10;
        isbn = isbn / 10;
     
        y = y + (mod * i);
   } 
    y = y % 11;
    if (y != 0)
    {
        printf("NO\n");
   }
   else
    {
        printf("YES\n");
   }
   
}

/*pseudocode: ask the user for an ISBN number
get the number using long_long
if modulus is 0 then the program should say 
that the ISBN is real 
but if the modulus is greater than 0 then the 
ISBN is false the do while loop can be used for this
remember: int tenth=x%10 - this finds the modulus, 
which would tell us what the tenth number is.
loops should be used instead of copying and pasting 
the modulus formula ten times.

*/


//Well done!!
//Grade: 14/14