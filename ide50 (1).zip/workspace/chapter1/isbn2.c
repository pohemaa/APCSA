#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

long isbn(); //prototype-warns the computer that these would be used later on. DON'T FREAK OUT!!!
int calculateISBN (long isbn);
int checkISBN(int sum);

int main (void)
{
    printf("ISBN:");
    long isbn= get_long_long();
    int sum = calculateISBN(isbn);
    checkISBN(sum); //call checkISBN
}    

int calculateISBN(long isbn)
{
    int y = 0;
    for(int i=10; i > 0; i--)
    {
        int mod = isbn % 10;
        isbn = isbn / 10;
        
        y = y + (mod * i);
        
    } 
    return y; //because the function is going to return a value.
}
    
int checkISBN(int sum)
{
    int y = sum % 11;

    if (y != 0)
    {
    printf("NO\n");
    }
    else
    {
    printf("YES\n");
    }
    return sum; //return a value.
}

/*pseudocode: ask the user for an ISBN number
get the number using long_long
if modulus is 0 then the program should say 
that the ISBN is real 
but if the modulus is greater than 0 then the 
ISBN is false the do while loop can be used for this
remember: int tenth=x%10 - this finds the modulus, 
which would tell us what the tenth number is.
loops should be used instead of copying and pasting 
the modulus formula ten times.

*/


//Well done!!
//Grade: 14/14
