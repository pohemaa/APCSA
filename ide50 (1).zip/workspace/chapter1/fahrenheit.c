#include <cs50.h>
#include <stdio.h>

int main(void)
{
    printf("What is the temperature in Celsius?");
    
   float number= get_float();
    
    
    printf("The temperature in Fahrenheit is: %0.1f\n",  number * 9 / 5+ 32);
    
    //yaaayyyyyy Gabriel helped and now it works. 
    /*Basic math operators have the same function in C too.
    To solve the mathematical problem above, the computer 
    uses the order of operations.
    */
    
    
}
 
 