#include <stdio.h>
#include <cs50.h>

int main(void)
{
    printf("Enter your name: ");
    string name = get_String();
    printf("hello, %s\n", name);
}

//Not a big deal, but you should start using comments to describe your code :)
//Grade: 8/8