#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(void)
{
   printf("Height: ");
   int height= get_int();
   if (height < 23 ||)
   {
       
   }
   else 
   {
       printf("Height:");
   }
}
    