#include <stdio.h>

int main(void)
{
    int i = 1;
    while ( i <= 50 )
    {
        printf(" %i\n", i);
        i++;
    }
}