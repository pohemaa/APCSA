#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{
    
    printf("Days in month:");
    
    
    int days= get_int();
    
    while (days<28||days>31){
     printf ("Days in month:");
     days=get_int();
    }
    
     printf("Pennies on first day:");
     
      double first_day=get_double();
     
      while(first_day <1){
      printf("Pennies on first day:");
      first_day = get_double();
     }
     
     double pennies;
    pennies=first_day;
    
   
     
    
   printf("$%.2f\n",( pennies * (pow(2,days)/100)-(first_day * 0.01)));
   
  
   
   
   //yayyyyy thank you Mrs. Hardy
   /*print a question to user
    get days of month
    check if >=28 and <=31
    ask again if out of range
    ask user how many pennies on 1st day
    for some # of days
    money *= pennies * (2^days)
    */
}   