#include <stdio.h>
#include <stdlib.h>
#include <cs50.h>

int main()
{
    printf("");
    int num_t = get_int();
    int score[num_t];
    int tot=0;
    
    for(int i=0; i<num_t; i++)
    {
        printf("scores:\n");
        int grades= get_int();
        score[i]= grades;
        tot = tot + score[i];
    }
        tot = tot / num_t;
    printf("The average is %d", tot);
   
 }
/*allow user to enter a series of test grades
*calculate an average of those grades
*identify its equivalent letter grade 
*identify the lowest and highest grade
* add your own features
* use functions and arrays. 
*/