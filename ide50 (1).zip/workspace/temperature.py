import cs50

print("Temperature in Kelvin:", end="")
k = cs50.get_float()
c = k - 273 
print("Celsius: {.1f}".format(c)) 
f = c * 9/5 + 32 
print("Fahrenheit: {.1f}".format(f)) 
