import cs50
 
while True:
    print ("Height:");
    height = cs50.get_int();
    if height > 0:
        i = 0
        for i in range(height):
            space = height - i
            print(" " * space, end="")
            has = i + 2
            print("#" * has)
            