class video5{
    public static void main(String args[]){
        double tuna;
        tuna = 5.28;
        
        System.out.print("I want ");
        System.out.print(tuna);
        System.out.println(" movies");
        System.out.print("apples");
    }
}