public class vid15 {
    public void simpleMessage(String name){
        System.out.println("Hello " + name);
    }
}