

class video10{
    public static void main(String args[]){
        
        int test = 6;
        
        if (test < 9){
            System.out.println("yes");
        }else{
            System.out.println("this is else");
        }
        
    }
}