public class vid14{
    public void simpleMessage(){
        System.out.println("This is another class");
    }
}