class video22{
    public static void main(String[] args){
        for(int counter = 6; counter <= 21; counter += 3){
            System.out.println(counter);
        }
    }
}