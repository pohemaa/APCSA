class video20{
    public static void main(String [] args){
        int age = 200;
        
        System.out.println(age > 50 ? "You are old": "you are young");
        
    }
}