import java.util.Scanner;

class video6{
    public static void main(String args[]){
        Scanner ohemaa = new Scanner(System.in);
        System.out.println(ohemaa.nextLine());
    }
}