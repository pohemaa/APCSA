class video17{
    public static void main(String[] args){
        vid17 vid17Object = new vid17("Kelsey");
        vid17 vid17Object2 = new vid17("Nicole");
        vid17Object.saying();
        vid17Object2.saying();
    }
}