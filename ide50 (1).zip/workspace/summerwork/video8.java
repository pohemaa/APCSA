import java.util.Scanner;

class video8{
    public static void main(String args[]){
        Scanner ohemaa = new Scanner(System.in);
       
       int girls, boys, people;
       girls =  7;
       boys = 3;
       people = girls % boys;
       System.out.println(people);
    }
}