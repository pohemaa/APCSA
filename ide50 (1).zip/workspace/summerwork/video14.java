import java.util.Scanner;

class video14{
    public static void main(String args[]){
        vid14 vid14Object = new vid14 ();
        vid14Object.simpleMessage();
    }
}