import java.util.Scanner;

class video7{
   public static void main(String args[]){
       Scanner ohemaa = new Scanner(System.in);
       double fnum, snum, answer;
       System.out.println("Enter first number: ");
       fnum = ohemaa.nextDouble();
       System.out.println("Enter second number: ");
       snum = ohemaa.nextDouble();
       answer = fnum + snum;
        System.out.println(answer);
   }
    
}