import java.util.Scanner;

class video9{
    public static void main(String args[]){
        Scanner ohemaa = new Scanner(System.in);
        
        int tuna = 5;
        int bass = 18;
         
        tuna *=8;
        
        System.out.println(tuna);
    }
}