class video25{
    public static void main(String[] args){
        System.out.println(Math.abs(-2.47));
        System.out.println(Math.ceil(7.4));
        System.out.println(Math.floor(7.8));
        System.out.println(Math.max(8.6, 5.2));
        System.out.println(Math.min(8.6, 5.2));
        System.out.println(Math.pow(5, 3));
        System.out.println(Math.sqrt(9));
    }
}