import java.lang.Math.*;
import java.util.*;
import java.util.Random;

public class test{
    public static void main(String [] args){
        Scanner scnr = new Scanner(System.in);
        Random randGen = new Random();

        System.out.println("What is the least number you want in the generator?");
        int userLow = scnr.nextInt();

        System.out.println("What is the highest number you want in the generator?");
        int userHigh = scnr.nextInt();

        int randNum = 0;

        for(int i = 0; i < userHigh; i++){
            randNum = randGen.nextInt((userHigh - userLow) + 1) + userLow;
            System.out.println(randNum);
        }
    }
}