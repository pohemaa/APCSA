import java.util.*;
import static java.lang.Math.*;
import java.lang.String;
import java.io.*;

public class mathCalc{

    public static void main(String [] args)

    {
        Scanner scnr = new Scanner(System.in);

        String loveMath = " ";
        String passWord = " ";


        System.out.println("Tell me about your love for Math in 8 words."); // Requirement 5

        loveMath = scnr.next();
        loveMath = loveMath.toUpperCase();
        char firstLetter = loveMath.charAt(0);


        loveMath = scnr.next();
        char secondLetter = loveMath.charAt(0);

        loveMath = scnr.next();
        char thirdLetter = loveMath.charAt(0);

        loveMath = scnr.next();
        char fourthLetter = loveMath.charAt(0);

        loveMath = scnr.next();
        loveMath = loveMath.toUpperCase();
        char fifthLetter = loveMath.charAt(0);


        loveMath = scnr.next();
        char sixthLetter = loveMath.charAt(0);

        loveMath = scnr.next();
        char seventhLetter = loveMath.charAt(0);

        loveMath = scnr.next();
        char eighthLetter = loveMath.charAt(0);



        passWord = "" + firstLetter + secondLetter + thirdLetter+ fourthLetter + fifthLetter + sixthLetter + seventhLetter + eighthLetter;
        //Requirement 6

        System.out.println("Password: "+ passWord );

        System.out.println("Hello! Welcome to Binary and Decimal number tutoring. Please log in.");
        System.out.println("Username: "); //Requirement 4
        String userName = scnr.nextLine();
        scnr.nextLine();

        System.out.println("Please input the password we gave you.");
        System.out.print("Password: ");
        String passWord1 = scnr.nextLine();

        if (passWord1.equals(passWord)){ //Requirement 7
            System.out.println("Login complete!");
        }else{
            System.out.println("Wrong password. Please try again.");
            System.out.print("Password: ");
            passWord1 = scnr.nextLine();
        }

        //Requirement 8
        System.out.println("What is binary? Binary is a base 2 number. This means that it consists of only two digits - 0's and 1's. How are these numbers increased? By raising the powers of 2.");

        int binCalc = (int)(Math.pow(2, 0) * 1) + (int)(Math.pow(2, 1) * 0) + (int)(Math.pow(2,2) * 1) + (int)(Math.pow(2, 3) * 1); //Requirement 2
        System.out.println("To convert binary number 1101 to a decimal number, you will need to raise each '2' to the power as you proceed from the left to the right. Therefore, 1101 is "+binCalc + " in decimal.");

        System.out.println("What is a decimal number? A decimal number is known as base 10 and consists of numbers from 0 to 9.");
        System.out.println("What if we wanted to convert 9 to binary? Let's imagine that we have a binary chart in our head. the first binary number is 2^0 which is 1, the second number is 2^1 which is 2,the 3rd number is 2^2, which is 4...and so on and so forth.");

        System.out.println("Therefore 9 = 0110 in binary.");
        System.out.println("The END! See you next time on Binary and Decimal number tutoring.");

        System.out.println("Welcome to Geometry tutoring! We will be reviewing triangles"); //Requirement 3
        System.out.println("If we want to find the side of a triangle based on a given angle, how do we go about this? We have three buddies to help us here today: tan, sin and cosin.");
        System.out.println("How does tan work? Tan is the tangent of an angle.");
        double tanCalc = tan(4); //Requirement 1

        System.out.println("Therefore the tangent of a 4 degree angle is: " + tanCalc);

        System.out.println("You have completed all the tutoring sessions. To sign out, you have to decode this ASCII message: 73 97109 837388 12110197114115 11110810046");
        String asciiCode = "I am SIX years old.";
        String asciiCode1 = scnr.nextLine();
        if (asciiCode1.equals(asciiCode)){ //Requirement 9 and 10
            System.out.println("Log out complete!");
        }else{
            System.out.println("Wrong message. Please try again.");
            System.out.print("Ascii message: ");
            asciiCode1 = scnr.nextLine();
        }



    }
}