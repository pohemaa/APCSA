import java.util.*;

public class rocketShip{
    public static void main(String [] args){

    Scanner scnr = new Scanner(System.in);
    int SIZE = scnr.nextInt();
    printCones(SIZE);
    printBorder(SIZE);
    body1(SIZE);
    onebox(SIZE);


    }
 public static void printCones(int s){

      for(int starCone = 1 ; starCone <= (s * 2)- 1 ; starCone++){
            for(int space = 1; space <= ( s * 2) - starCone; space++){
                System.out.print(" ");
            }
            for(int fslash = 1 ; fslash != starCone + 1 ; fslash++){
                System.out.print("/");
            }
            System.out.print("**");
            for(int bslash = 1 ; bslash != starCone + 1; bslash++){
                System.out.print("\\");
            }
            System.out.println();
        }
 }

 public static void printBorder(int b){
     System.out.print("+");
     for(int spec = 1; spec <= b * 2; spec++){
         System.out.print("=*");
     }
     System.out.println("+");

 }

public static void body1(int d){
        for(int halfsize = 1 ; halfsize <= d ; halfsize++){
            System.out.print("|");
            for(int halfdot = d - 1 ; halfdot >= halfsize ; halfdot--){
                System.out.print(".");
            }
            for(int slash1 = 1 ; slash1 <= halfsize ; slash1++){
                System.out.print("/\\");
            }
            for(int halfdot2 = ((d * 2) - 2) / 2 ; halfdot2 >= halfsize; halfdot2--){
                System.out.print("..");
            }
            for(int slash2 = 1 ; slash2 <= halfsize ; slash2++){
                System.out.print("/\\");
            }
            for(int halfdot2 = d - 1 ; halfdot2 >= halfsize ; halfdot2--){
                System.out.print(".");
            }
            System.out.print("|");
            System.out.println();
        }
    }

     public static void onebox(int l){
        for(int halfsize = 1 ; halfsize <= l ; halfsize++){
            System.out.print("|");
            for(int halfdot = 1 ; halfdot <= (halfsize - 1); halfdot++){
                System.out.print(".");
            }
            for(int slash1 = l ; slash1 >= halfsize; slash1--){
                System.out.print("\\/");
            }
            for(int halfdot2 = 0 ; halfdot2 <= halfsize-2 ; halfdot2++){
                System.out.print("..");
            }
            for(int slash2 = l ; slash2 >= halfsize; slash2--){
                System.out.print("\\/");
            }
            for(int halfdot3 = 1 ; halfdot3 <= (halfsize - 1); halfdot3++){
                System.out.print(".");
            }
            System.out.print("|");
            System.out.println();
        }
}
}