import java.util.*;
import java.lang.Math;

public class userInput{
    public static void main(String [] args){
        Scanner scnr = new Scanner(System.in);
        
        final int dogTimesHuman = 7; //apparently to calculate a dog's age, you calculate it by 7.
        int yesNoDog, yesNoCat, yesNoRat, yesNoHamster = 0;   // I decided to make the user input their answers using numbers for yesNoDog.
        double petAverage = 0.0;
        final double smallBreed = 5.33;
        final double mediumBreed = 6.16;
        String numPets;
        double dogInHuman = 0.0;
        int dogAge, catAge, hamsterAge = 0;
        int ratAge = 0;
        
        int catInHumanMulti = 56 % 10;
        /*  instead of creating a final catInHuman, I will calculate it.
        According to an online site, a 10 year old cat will be 56 in human years.
        I am going to use the modulus operator to find the number of human years we have to multiply by catAge
        */
        int catInHuman = 0;
        
        System.out.println("How many pets do you have? (one, two, three or four");
        numPets = scnr.nextLine();
        
        System.out.println("Do you have a dog? 1 or 0 (yes = 1 or no = 0)");
        yesNoDog = scnr.nextInt();
        
        if (yesNoDog == 1){
            
        System.out.println("How old is your dog?");
        dogAge = scnr.nextInt();
        
        System.out.println("Is it a small breed or medium breed? 1 or 0 (smallBreed = 1, mediumBreed = 0");
        int dogBreed = scnr.nextInt();
        
        if(dogBreed == 1){
            
           dogInHuman = dogAge * smallBreed;
           
        }else{
            
            dogInHuman = dogAge * mediumBreed;
            
        }
       
        System.out.println("Your dog is "+ dogInHuman+ " in human years.");
        }
            
        System.out.println("Do you have a cat? yes =1 or no = 0");
        yesNoCat = scnr.nextInt();
        
        if(yesNoCat == 1){
            System.out.println("How old is your cat?");
            catAge = scnr.nextInt();
            
            catInHuman = catInHumanMulti * catAge;
            System.out.println("Your cat is "+ catInHuman + " in human years."); 
        }
        
        System.out.println("Do you have a rat? yes =1 or no = 0");
        yesNoRat = scnr.nextInt();
        
        if(yesNoRat == 1){
            System.out.println("How old is your rat?");
            ratAge = scnr.nextInt();
            System.out.println("Your rat is "+ ratAge + " in human years."); 
        }
        
        System.out.println("Do you have a hamster? yes = 1 or no = 0");
        yesNoHamster = scnr.nextInt();
        
        if (yesNoHamster == 1){
            System.out.println("How old is your hamster?");
            hamsterAge = scnr.nextInt();
            System.out.println("Your hamster is "+ hamsterAge);
        }
        
        if (yesNoHamster == 1 && yesNoRat == 1 && yesNoDog ==1 && yesNoCat == 1){
            petAverage = ((ratAge + catInHuman + dogInHuman + hamsterAge)/4);
            System.out.println("The average of pet age in human years is " + petAverage);
        }
        
        
    }
}