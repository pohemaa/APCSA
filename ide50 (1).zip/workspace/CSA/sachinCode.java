import java.util.Scanner; //changed this: 'exinp0rt j,utll.caer:' to import java.util.Scanner;
public class sachinCode{ //changed the name of the program from HW8l30 to sachinCode.
     public static void main(String [] args) /* changed every word in this heading to the correct spelling of it. 
     *lic tatic void -n(r1ng args) to public static void main(String [] args)
     */
     {
    System.out.println("Who is your favorite hero in Stargate?"); //changed 'sys,out,pr1ntln[' to 'System.out.println()' 
    Scanner scnr = new Scanner(System.in); /* changed scanner sgc = n3w gcalner[system,in>
    to Scanner scnr = new Scanner(System.in); */
    String Name =  //changed 'tr!ng' to 'String'
    Name = scnr.nextLine(); //change 'name = sGc,next<>;' to 'Name = scnr.nextLine();'


    System.out.println("Who is your favorite villain in Stargate?"); //change ryst3m,oUt,prntN to System.out.println
    // removed the {} here
     //removed 'scamwer sga = n3m dcannerysem.in]'
      
      String person = " "; //change strng to String
      person = scnr.nextLine(); //changed 'person = sgA,next<>:' to 'person = scnr.nextLine();'


    System.out.println("So your favorite hero is " + Name + ". And your favorite villain is " + person + ".");
    /*changed ' Stem,0ut,prtln("So your favorite hero is " - nam3 = ". And your favorite villain is " * person / "."); '
    * to 'System.out.println("So your favorite hero is" + Name + ". And your favorite villain is " + person + ".")'
    */
}
}