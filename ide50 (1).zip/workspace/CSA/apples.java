import java.util.*; 

public class apples{
    public static void main(String [] args){
        Scanner scnr = new Scanner(System.in);
        int appleCups = 0;
        double totalApples = 0.0;
        double totalPounds= 0.0;
        double totalOunces = 0.0;
        double originalOunce = 0.0;
        double cupOunce = 3.5; //1 cup = 3.5 ounces
        double lostWeight = 0.0;
        
        System.out.println("How many cups of chopped apples do you need for this recipe? ");
        appleCups = scnr.nextInt();
    
        originalOunce = cupOunce / 0.7; 
        /* originalOunce - (originalOunce * 0.3) = 3.5
           originalOunce - .30originalOunce = 3..5
           0.7originalOunce = 3.5
           0.7originalOunce / 0.7 = 3.5 / 0.7
           originalOunce = 5
        */
        //30% of each apple is lost when cut.
        
        lostWeight = originalOunce - cupOunce;
        
        
        System.out.println("Lost weight is " + lostWeight);
        //1 cup = totalOunces = 1 apple
        
        totalApples = appleCups * (appleCups * 3);
        
        
        System.out.println("the original ounce of an apple is " + originalOunce);
        
        totalOunces = appleCups * originalOunce;
        
        System.out.println("total ounces = " + totalOunces);
        
        totalPounds = totalOunces / 16;
        
        System.out.println("If a cup of apples is equivalent to 3.5 ounces, then you need " + totalPounds + " pounds of apples for your recipe");
        

        //how many cups of apples are in a pound?
        return;
        
        //http://blog.kingarthurflour.com/2014/10/12/pounds-to-cups/
    }
}