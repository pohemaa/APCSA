import java.util.Random; //changed the comma to '.'

public class brokenCode //added 'public' to this heading.
{
    public static void main(String [] args)//changed '{}' to '[]' and placed it in between 'String' and 'arg'.
    //Changed 'arg' to 'args'removed the semicolon
    {
        Random ticket = new Random();
        int number;
    
    for(int counter= 1; counter<= 1; counter++) //changed the colon to a semicolon 
    {
        number = 1 + ticket.nextInt(50);
        System.out.print("the winner to the lottery has ticket number:");
        System.out.println(number); //the quotes are not needed here.
    }
  }
}