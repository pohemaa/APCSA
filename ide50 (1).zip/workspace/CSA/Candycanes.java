public class Candycanes {
public static void main(String [] args) {

//This program is suppose to calculate how many candycanes are in three jars. 
// I (Ohemaa)put a second front slash in this comment,

    int jars = 3; //I (Ohemaa) changed all the Int to int
    int candycane = 30; // I (Ohemaa) added a semicolon after 30.
    int totalcandycane = 0;
    
    totalcandycane = 30 * 3; // I (Ohemaa) added this piece of code to calculate the number of candy canes in 3 jars.
    
    System.out.println(candycane + " number of candy canes in " + jars 
    + " jars equals " + totalcandycane + " candy canes.");
    
    // I (Ohemaa) made this a 'println' and not 'print'
    
    /*added " candycanes." and changed 
    'System.out.print(candycane + number of candcanes in " + jars + " equals " + totalcandycane);'
    * to 'System.out.println(candycane + " number of candy canes in " + jars + " jars equals " 
    + totalcandycane + " candy canes.");'
    */

}
} //I (Ohemaa) added an ending curly bracket here.