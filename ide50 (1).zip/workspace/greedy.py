import cs50

print("Change:", end="");
change = cs50.get_float();
change = round(change * 100.0,0)
print(change)
quarters = round(change // 25,0)
print(quarters)
remainder = round(change % 25,0)
dime = round(remainder // 10, 0)
print(dime)
remainder2 = round(remainder % 10, 0)
nickels = round(remainder2 // 5, 0)
print(nickels)
remainder3 = round(nickels % 5, 0)
pennies = round(remainder3 // 1, 0)
print(pennies)